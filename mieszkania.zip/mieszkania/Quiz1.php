<!DOCTYPE html>
<html>
<head>
    <title> Mieszkania </title>
    <meta charset='UTF-8'>
    <link rel='stylesheet' href='css.css'>
    <script src="skrypty.js"> </script>
</head>
<body>
<header>
    <a href="StronaGlowna.html"  ><img src="logo.png" id="logo"></a> 
        <div id="nav">
        
            <a href="Mieszkania.html">&nbsp &nbsp &nbsp Mieszkania</a>
            <a href="mapa.html">&nbsp &nbsp Mapa &nbsp &nbsp</a>
            <a href="Ogłoszenia.html" id="add"> + Dodaj ogłoszenie</a>
            <a href="Quiz.html"> &nbsp &nbsp &nbsp &nbsp <img src="czglowa.png" id="glowa"> </a>
            <a href="polubione.html"> <img src="blackHeart.png" id="blackHeart"> </a>
            <a href="konto.html"><img src="profile.png" id="profile"></a>
        </div>
    </header>
	<br><br>
    <div id="main1">
	<div id="border">
	
<form action ="wynik.php" method ="get">
    <h2>
        Pytanie 1.
    </h2>
    <h5>
        Lubisz gdy wszystko dzieje się nagle i dookoła występuje spontaniczność?
    </h5>
	<p>
    <input type="radio" name="odp"  value="Tak"> Tak <br><br>
  <input type="radio" name="odp" value="Nie"> Nie
   
<br>

<h2>
        Pytanie 2.
    </h2>
    <h5>
       Preferujesz ład oraz przestrzenność?
    </h5>
	<p>
    <input type="radio" name="odp1"  value="Tak1"> Tak <br><br>
  <input type="radio" name="odp1" value="Nie1"> Nie
    <br>

<h2>
        Pytanie 3.
    </h2>
    <h5>
        Jaskrawość powinna dominować nad mrokiem?
    </h5>
	<p>
    <input type="radio" name="odp2"  value="Tak2"> Tak <br><br>
  <input type="radio" name="odp2" value="Nie2"> Nie
    <br>

<h2>
        Pytanie 4.
    </h2>
    <h5>
        Szukasz mieszkania dla więcej niż 3 osób?
    </h5>
	<p>
    <input type="radio" name="odp3"  value="Tak3"> Tak <br><br>
  <input type="radio" name="odp3" value="Nie3"> Nie
    <br>
 <input id="button3" type="submit" value="Dalej">
	</div>
	
</div>
<br> <br>

</form>



<footer>

<a id="aFooter">Regulamin</a><a id="aFooter">Kontakt</a><a id="aFooter">Usługi</a><a id="aFooter">Inwestycje deweloperskie</a>

<img src="twitter.png" id="ikona1"> <img src="facebook.png" id="ikona"> <img src="instagram.png" id="ikona"> <img src="email.png" id="ikona">
</footer>   
</body>
</html>