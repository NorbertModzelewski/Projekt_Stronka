<!DOCTYPE html>
<html>
<head>
    <title> Mieszkania </title>
    <meta charset='UTF-8'>
    <link rel='stylesheet' href='css.css'>
    <script src="skrypty.js"> </script>
</head>
<body>
<header>
    <a href="StronaGlowna.html"  ><img src="logo.png" id="logo"></a> 
        <div id="nav">
        
            <a href="Mieszkania.html">&nbsp &nbsp &nbsp Mieszkania</a>
            <a href="mapa.html">&nbsp &nbsp Mapa &nbsp &nbsp</a>
            <a href="Ogłoszenia.html" id="add"> + Dodaj ogłoszenie</a>
            <a href="Quiz.html"> &nbsp &nbsp &nbsp &nbsp <img src="czglowa.png" id="glowa"> </a>
            <a href="polubione.html"> <img src="blackHeart.png" id="blackHeart"> </a>
            <a href="konto.html"><img src="profile.png" id="profile"></a>
        </div>
    </header>
	<br><br>
    <div id="main1">
	<div id="border1">
	<div id="preferencje">
<h2>
<b> TWOJE PREFERENCJE </b> </h2>
<?php switch($_GET['odp']){
   case "Tak":
     echo "Lokalizacja: Centrum miasta.";
     break;
   case "Nie":
     echo "Lokalizacja: Obrzeża miasta.";
     break;
   }
?>
<br><br><br>
<?php switch($_GET['odp1']){
   case "Tak1":
     echo "Nieruchomość: Dom wolnostojący.";
     break;
   case "Nie1":
     echo "Nieruchomość: Blok.";
     break;
   }
?>
<br><br><br>
<?php switch($_GET['odp2']){
   case "Tak2":
     echo "Kolorystyka: Jaskrawa.";
     break;
   case "Nie2":
     echo "Kolorystyka: Mrok.";
     break;
   }

?>
<br><br><br>
<?php switch($_GET['odp3']){
   case "Tak3":
     echo "Wielkość: Sporych rozmiarów";
     break;
   case "Nie3":
     echo "Wielkość: Małych/Średnich rozmiarów";
     break;
   }
?>
</div>
<div id="zdjprawo">
<img src="domwo.jpg" id="woda">
<br><br>
<h4>Sprawdź przypisane ogłoszenia</h4>
<br>
  <a href="Ogłoszenia.html">  <input id="button3"  type="button" value="     Dalej     "> </a>
</div>
</div>
</div>
<br> <br>



<footer>

<a id="aFooter">Regulamin</a><a id="aFooter">Kontakt</a><a id="aFooter">Usługi</a><a id="aFooter">Inwestycje deweloperskie</a>

<img src="twitter.png" id="ikona1"> <img src="facebook.png" id="ikona"> <img src="instagram.png" id="ikona"> <img src="email.png" id="ikona">
</footer>   
</body>
</html>